import re
from typing import Dict, List

def process_log_file(log_content: str) -> Dict[str, any]:
    """
    Processes a log string to extract error details.

    Args:
        log_content (str): Log entries as a single string.

    Returns:
        Dict[str, any]: A dictionary with total error count and unique error messages.
    """
    # Validate input type
    if not isinstance(log_content, str):
        raise ValueError("log_content must be a string.")
    
    # Handle empty or whitespace-only input
    if not log_content.strip():
        return {"total_errors": 0, "unique_error_messages": []}
    
    # Regular expression to extract error messages
    error_pattern = r"\[.*?\] ERROR: (.+)"
    error_messages = re.findall(error_pattern, log_content)
    
    # Generate results
    return {
        "total_errors": len(error_messages),
        "unique_error_messages": sorted(set(error_messages))
    }
