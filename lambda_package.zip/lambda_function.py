import json
from process_log import process_log_file

def lambda_handler(event, context):
    """
    AWS Lambda handler function.

    Args:
        event (dict): Event data containing 'candidate_id' and 'log_content'.
        context: AWS context (not used here).

    Returns:
        dict: Lambda response.
    """
    try:
        candidate_id = event.get("candidate_id", "UNKNOWN_ID")
        log_content = event.get("log_content", "")

        # Process log file
        result = process_log_file(log_content)
        
        return {
            "statusCode": 200,
            "body": json.dumps({
                "candidate_id": candidate_id,
                "result": result
            })
        }
    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
